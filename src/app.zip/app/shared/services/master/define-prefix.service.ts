import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/shared/utils/http.service';
import { ApiResponse } from 'src/app/shared/models/api-response.model';

/* ================= DTOs ================= */
export interface PrefixLinkDto {
  prodPrefix: string;
  accountCode: string;
  description?: string;
  vchrType: string;
  prodPrefixType: string;
  prodLevyType: string;      // 'L' = Levy, 'P' = Product
  dbcrFlag: string;          // 'D' or 'C'
  customerName?: string;
  objectStatus?: string;
}

export interface AccountLookupDto {
  accountCode: string;
  description: string;
}

export interface CustomerLookupDto {
  customerCode: string;
  customerName: string;
}

export interface PrefixRowPayload {
  prodPrefix: string;
  accountCode: string;
  prodLevyType: string;
  dbcrFlag: string;
}

export interface SavePrefixLinksPayload {
  vchrType: string;
  prefixType: string;
  rows: PrefixRowPayload[];
  username: string;
  location: string;
}

export interface DeletePrefixLinkPayload {
  prodPrefix: string;
  accountCode: string;
  vchrType: string;
  prefixType: string;
}

/* ================= SERVICE ================= */
@Injectable({ providedIn: 'root' })
export class DefinePrefixService {

  constructor(private http: HttpService) { }

  getLinks(vchrType: string, prefixType: string): Observable<ApiResponse<PrefixLinkDto[]>> {
    return this.http.get<ApiResponse<PrefixLinkDto[]>>(
      `DefinePrefix/GetLinks/${encodeURIComponent(vchrType)}/${encodeURIComponent(prefixType)}`
    );
  }

  getAccounts(): Observable<ApiResponse<AccountLookupDto[]>> {
    return this.http.get<ApiResponse<AccountLookupDto[]>>('DefinePrefix/GetAccounts');
  }

  getCustomers(): Observable<ApiResponse<CustomerLookupDto[]>> {
    return this.http.get<ApiResponse<CustomerLookupDto[]>>('DefinePrefix/GetCustomers');
  }

  saveLinks(payload: SavePrefixLinksPayload): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>('DefinePrefix/SaveLinks', payload);
  }

  deleteLink(payload: DeletePrefixLinkPayload): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>('DefinePrefix/DeleteLink', payload);
  }
}
