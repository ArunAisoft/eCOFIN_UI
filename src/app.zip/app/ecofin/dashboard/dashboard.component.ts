import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ViewChild, ElementRef, ChangeDetectorRef
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { finalize } from 'rxjs';
import { Chart, registerables } from 'chart.js';
import { AlertService }      from 'src/app/shared/utils/alert.service';
import { normalizeResponse } from 'src/app/shared/utils/normalize-response.service';
import { DashboardService }  from 'src/app/shared/services/voucher/dashboard.service';
import {
  DashboardSummaryDto, DashboardKpiDto,
  VoucherTypeMetricDto, VoucherTypeDrillDto,
  BankSummaryDto, RecentVoucherDto, MonthlyTrendDto,
  VOUCHER_TYPE_CONFIG, VoucherTypeConfig
} from 'src/app/shared/models/dashboard.models';

Chart.register(...registerables);

@Component({
  selector:    'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls:   ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {

  // ── Canvas refs ────────────────────────────────────────────────────────
  @ViewChild('barChartRef')   barChartRef!:   ElementRef<HTMLCanvasElement>;
  @ViewChild('donutChartRef') donutChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('lineChartRef')  lineChartRef!:  ElementRef<HTMLCanvasElement>;
  @ViewChild('stackChartRef') stackChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('drillChartRef') drillChartRef!: ElementRef<HTMLCanvasElement>;

  // ── State ──────────────────────────────────────────────────────────────
  userName:       string  = '';
  isLoading:      boolean = false;
  isDrillLoading: boolean = false;

  // ── Data ───────────────────────────────────────────────────────────────
  summary:          DashboardSummaryDto | null = null;
  kpi:              DashboardKpiDto     | null = null;
  voucherMetrics:   VoucherTypeMetricDto[]     = [];
  bankSummary:      BankSummaryDto[]           = [];
  monthlyTrend:     MonthlyTrendDto[]          = [];
  recentVouchers:   RecentVoucherDto[]         = [];
  drillData:        VoucherTypeDrillDto | null = null;
  expandedBankCode: string              | null = null;

  // ── Filters ────────────────────────────────────────────────────────────
  filterForm!:         FormGroup;
  selectedVoucherType: VoucherTypeConfig | null = null;
  selectedStatus:      string = '';

  readonly voucherTypeConfig: VoucherTypeConfig[] = VOUCHER_TYPE_CONFIG;
  readonly statusOptions = [
    { label: 'All statuses', value: ''       },
    { label: 'Posted',       value: 'Post'   },
    { label: 'On Hold',      value: 'ONHOLD' },
    { label: 'Draft',        value: 'Draft'  },
  ];

  // ── Chart instances ────────────────────────────────────────────────────
  private barChart:   Chart | null = null;
  private donutChart: Chart | null = null;
  private lineChart:  Chart | null = null;
  private stackChart: Chart | null = null;
  private drillChart: Chart | null = null;

  private readonly CHART_COLORS = VOUCHER_TYPE_CONFIG.map(v => v.color);
  private readonly GRID_COLOR   = 'rgba(128,128,128,0.1)';
  private readonly TICK_COLOR   = 'rgba(128,128,128,0.6)';

  constructor(
    private fb:               FormBuilder,
    private dashboardService: DashboardService,
    private alertService:     AlertService,
    private cdr:              ChangeDetectorRef
  ) {}

  // ── Lifecycle ──────────────────────────────────────────────────────────

  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.userName   = localStorage.getItem('userName') ?? '';
    this.filterForm = this.fb.group({ bankCode: [null], accPeriod: [null] });
    this.loadSummary();
  }

  ngAfterViewInit(): void {}

  ngOnDestroy(): void {
    this.destroyAllCharts();
  }

  // ── Form getters ───────────────────────────────────────────────────────

  get bankCodeControl()  { return this.filterForm.get('bankCode')  as FormControl; }
  get accPeriodControl() { return this.filterForm.get('accPeriod') as FormControl; }

  // ── Load summary ───────────────────────────────────────────────────────

  loadSummary(): void {
    const { bankCode, accPeriod } = this.filterForm.value;
    this.isLoading = true;
    this.destroyAllCharts();

    normalizeResponse<any>(
      this.dashboardService.getSummary(
        this.userName, bankCode ?? undefined, accPeriod ?? undefined
      ),
      'Dashboard'
    )
    .pipe(finalize(() => (this.isLoading = false)))
    .subscribe({
      next: res => {
        if (res.status === 200) {
          const data = res.data;
          if (!data) { this.alertService.warning('No dashboard data found.'); return; }

          this.summary        = data;
          this.kpi            = data.kpi;
          this.voucherMetrics = data.voucherMetrics ?? [];
          this.bankSummary    = data.bankSummary    ?? [];
          this.monthlyTrend   = data.monthlyTrend   ?? [];
          this.recentVouchers = data.recentVouchers ?? [];

          // ── Auto-select latest period on first load ──────────────────
          // Picks the entry with highest sequence (latest active period).
          // { emitEvent: false } prevents triggering valueChanges → no reload loop.
          if (this.monthlyTrend.length && !this.accPeriodControl.value) {
            const latest = this.monthlyTrend
              .reduce((max, m) => m.sequence > max.sequence ? m : max);
            this.accPeriodControl.setValue(latest.accPeriod, { emitEvent: false });
          }

          // Force *ngIf to render <canvas> before Chart.js looks for them
          this.cdr.detectChanges();
          setTimeout(() => this.buildAllCharts(), 0);
          return;
        }
        this.alertService.showCommonError(res.status, res.message, 'Dashboard');
      },
      error: (err: any) =>
        this.alertService.showCommonError(
          err?.status || 0, err?.error?.message || err?.message, 'Dashboard'
        )
    });
  }

  onFilterChange(): void {
    this.drillData = null;
    this.selectedVoucherType = null;
    this.loadSummary();
  }

  onResetFilters(): void {
    this.filterForm.reset();
    this.selectedVoucherType = null;
    this.selectedStatus      = '';
    this.drillData           = null;
    this.loadSummary();
  }

  // ── Drill-down ─────────────────────────────────────────────────────────

  selectVoucherType(cfg: VoucherTypeConfig): void {
    if (!cfg) return;
    if (this.selectedVoucherType?.code === cfg.code) {
      this.selectedVoucherType = null;
      this.drillData = null;
      return;
    }
    this.selectedVoucherType = cfg;
    this.loadDrillDown(cfg.code);
  }

  private loadDrillDown(sysCategory: string): void {
    const { bankCode } = this.filterForm.value;
    this.isDrillLoading = true;
    this.destroyDrillChart();

    normalizeResponse<any>(
      this.dashboardService.getDrillDown(
        sysCategory, this.userName, bankCode ?? undefined
      ),
      'Drill Down'
    )
    .pipe(finalize(() => (this.isDrillLoading = false)))
    .subscribe({
      next: res => {
        if (res.status === 200) {
          const data = res.data;
          if (!data) { this.alertService.warning('No drill-down data found.'); return; }
          this.drillData = data;
          this.cdr.detectChanges();
          setTimeout(() => this.buildDrillChart(data.monthlyVolume ?? []), 0);
          return;
        }
        this.alertService.showCommonError(res.status, res.message, 'Drill Down');
      },
      error: (err: any) =>
        this.alertService.showCommonError(
          err?.status || 0, err?.error?.message || err?.message, 'Drill Down'
        )
    });
  }

  closeDrillDown(): void {
    this.drillData           = null;
    this.selectedVoucherType = null;
    this.destroyDrillChart();
  }

  toggleBankExpand(bankCode: string): void {
    this.expandedBankCode = this.expandedBankCode === bankCode ? null : bankCode;
  }

  // ── Computed ───────────────────────────────────────────────────────────

  get filteredRecentVouchers(): RecentVoucherDto[] {
    let rows = this.recentVouchers;
    if (this.selectedVoucherType)
      rows = rows.filter(r => r.voucherSysCat === this.selectedVoucherType!.code);
    if (this.selectedStatus)
      rows = rows.filter(r => r.ctrlStatus === this.selectedStatus);
    return rows;
  }

  onStatusFilterChange(status: string): void { this.selectedStatus = status; }

  // ── Charts ─────────────────────────────────────────────────────────────

  private buildAllCharts(): void {
    this.buildBarChart();
    this.buildDonutChart();
    this.buildLineChart();
    this.buildStackChart();
  }

  private buildBarChart(): void {
    if (!this.barChartRef?.nativeElement || !this.voucherMetrics.length) return;
    this.barChart?.destroy();
    this.barChart = new Chart(this.barChartRef.nativeElement, {
      type: 'bar',
      data: {
        labels:   this.voucherMetrics.map(v => v.voucherSysCategory),
        datasets: [{ label: 'Total vouchers', data: this.voucherMetrics.map(v => v.totalCount), backgroundColor: this.CHART_COLORS, borderRadius: 4 }]
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: this.GRID_COLOR }, ticks: { color: this.TICK_COLOR } },
          y: { grid: { display: false },         ticks: { color: this.TICK_COLOR } }
        },
        onClick: (_e, els) => {
          if (!els.length) return;
          const cfg = this.voucherTypeConfig.find(v => v.code === this.voucherMetrics[els[0].index]?.voucherSysCategory);
          if (cfg) this.selectVoucherType(cfg);
        }
      }
    });
  }

  private buildDonutChart(): void {
    if (!this.donutChartRef?.nativeElement || !this.voucherMetrics.length) return;
    this.donutChart?.destroy();
    this.donutChart = new Chart(this.donutChartRef.nativeElement, {
      type: 'doughnut',
      data: {
        labels:   this.voucherMetrics.map(v => `${v.voucherSysCategory} ₹${this.fmtLakh(v.postedAmount)}L`),
        datasets: [{ data: this.voucherMetrics.map(v => v.postedAmount), backgroundColor: this.CHART_COLORS, borderWidth: 0, hoverOffset: 6 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '62%',
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => ` ₹${this.fmtAmount(ctx.raw as number)}` } }
        },
        onClick: (_e, els) => {
          if (!els.length) return;
          const cfg = this.voucherTypeConfig.find(v => v.code === this.voucherMetrics[els[0].index]?.voucherSysCategory);
          if (cfg) this.selectVoucherType(cfg);
        }
      }
    });
  }

  private buildLineChart(): void {
    if (!this.lineChartRef?.nativeElement || !this.monthlyTrend.length) return;
    this.lineChart?.destroy();
    const labels    = this.monthlyTrend.map(m => m.accPeriod);
    const groupKeys = [...new Set(this.monthlyTrend.flatMap(m => m.groups.map(g => g.voucherGroup)))].sort();
    const groupColors: Record<string, string> = {
      BNK: '#378ADD', CASH: '#D85A30', SALE: '#7F77DD', PURCH: '#D4537E',
      CONTRA: '#534AB7', JRNL: '#888780', DBNOT: '#E24B4A', CRNOT: '#0F6E56',
    };
    this.lineChart = new Chart(this.lineChartRef.nativeElement, {
      type: 'line',
      data: {
        labels,
        datasets: groupKeys.map((key, i) => ({
          label:           key,
          data:            this.monthlyTrend.map(m => m.groups.find(g => g.voucherGroup === key)?.postedAmount ?? 0),
          borderColor:     groupColors[key] ?? this.CHART_COLORS[i % this.CHART_COLORS.length],
          backgroundColor: 'transparent',
          tension: 0.4, borderDash: i > 1 ? [5, 3] : [], pointRadius: 3,
        }))
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } },
        scales: {
          x: { grid: { color: this.GRID_COLOR }, ticks: { color: this.TICK_COLOR, maxRotation: 0 } },
          y: { grid: { color: this.GRID_COLOR }, ticks: { color: this.TICK_COLOR, callback: v => `₹${this.fmtLakh(+v)}L` } }
        }
      }
    });
  }

  private buildStackChart(): void {
    if (!this.stackChartRef?.nativeElement || !this.voucherMetrics.length) return;
    this.stackChart?.destroy();
    this.stackChart = new Chart(this.stackChartRef.nativeElement, {
      type: 'bar',
      data: {
        labels:   this.voucherMetrics.map(v => v.voucherSysCategory),
        datasets: [
          { label: 'Posted',  data: this.voucherMetrics.map(v => v.postedCount),  backgroundColor: '#1D9E75', borderRadius: 3 },
          { label: 'On Hold', data: this.voucherMetrics.map(v => v.onHoldCount),  backgroundColor: '#BA7517', borderRadius: 3 },
          { label: 'Draft',   data: this.voucherMetrics.map(v => v.draftCount),   backgroundColor: '#888780', borderRadius: 3 },
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } },
        scales: {
          x: { stacked: true, grid: { display: false },        ticks: { color: this.TICK_COLOR } },
          y: { stacked: true, grid: { color: this.GRID_COLOR }, ticks: { color: this.TICK_COLOR } }
        }
      }
    });
  }

  private buildDrillChart(monthlyVolume: { accPeriod: string; count: number; amount: number }[]): void {
    if (!this.drillChartRef?.nativeElement || !monthlyVolume.length) return;
    this.destroyDrillChart();
    const color = this.selectedVoucherType?.color ?? '#378ADD';
    this.drillChart = new Chart(this.drillChartRef.nativeElement, {
      type: 'bar',
      data: {
        labels:   monthlyVolume.map(m => m.accPeriod),
        datasets: [{ label: 'Volume', data: monthlyVolume.map(m => m.count), backgroundColor: color + 'CC', borderRadius: 3 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false },        ticks: { color: this.TICK_COLOR, font: { size: 10 }, maxRotation: 0 } },
          y: { grid: { color: this.GRID_COLOR }, ticks: { color: this.TICK_COLOR, font: { size: 10 } } }
        }
      }
    });
  }

  private destroyAllCharts(): void {
    [this.barChart, this.donutChart, this.lineChart, this.stackChart, this.drillChart].forEach(c => c?.destroy());
    this.barChart = this.donutChart = this.lineChart = this.stackChart = this.drillChart = null;
  }

  private destroyDrillChart(): void {
    this.drillChart?.destroy();
    this.drillChart = null;
  }

  // ── Helpers ────────────────────────────────────────────────────────────

  getVoucherConfig(code: string): VoucherTypeConfig | undefined {
    return this.voucherTypeConfig.find(v => v.code === code);
  }

  statusLabel(status: string): string {
    const map: Record<string, string> = { Post: 'Posted', ONHOLD: 'On Hold', Draft: 'Draft' };
    return map[status] ?? status;
  }

  fmtAmount(val: number | null | undefined): string {
    if (val == null) return '₹0';
    return '₹' + val.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  }

  fmtLakh(val: number): string { return (val / 100000).toFixed(1); }

  postedPct(m: VoucherTypeMetricDto): number {
    return m.totalCount > 0 ? Math.round((m.postedCount / m.totalCount) * 100) : 0;
  }

  onHoldPct(m: VoucherTypeMetricDto): number {
    return m.totalCount > 0 ? Math.round((m.onHoldCount / m.totalCount) * 100) : 0;
  }

  trackByCode(_: number, item: VoucherTypeMetricDto): string { return item.voucherSysCategory; }
  trackByCfgCode(_: number, item: VoucherTypeConfig): string { return item.code; }
  trackByBank(_: number, item: BankSummaryDto): string       { return item.bankCode; }
  trackByVchr(_: number, item: RecentVoucherDto): string     { return item.voucherNo; }
}