import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import { AlertService } from 'src/app/shared/utils/alert.service';
import {
  DefinePrefixService,
  PrefixLinkDto,
  AccountLookupDto,
  CustomerLookupDto
} from 'src/app/shared/services/master/define-prefix.service';

@Component({
  selector: 'app-oprefix',
  templateUrl: './oprefix.component.html',
  styleUrls: ['./oprefix.component.css'],
})
export class OprefixComponent implements OnInit {

  isLoading = false;
  isSaving = false;
  userName = '';
  private _searchText = '';

  prefixForm!: FormGroup;

  accountList: AccountLookupDto[] = [];
  customerList: CustomerLookupDto[] = [];
  accountMap = new Map<string, string>();
  customerMap = new Map<string, string>();
  filteredRowIndexes: number[] = [];

  readonly vchrTypeOptions = [
    { value: 'I', label: 'Purchase' },
    { value: 'P', label: 'Sales' }
  ];

  readonly prefixTypeOptions = [
    { value: 'D', label: 'Domestic' },
    { value: 'I', label: 'Import/Export' }
  ];

  readonly levyTypeOptions = [
    { value: 'L', label: 'Levy' },
    { value: 'P', label: 'Product' }
  ];

  readonly dbcrOptions = [
    { value: 'D', label: 'Debit' },
    { value: 'C', label: 'Credit' }
  ];

  constructor(
    private fb: FormBuilder,
    private svc: DefinePrefixService,
    private alertService: AlertService
  ) { }

ngOnInit(): void {
  console.log('ngOnInit');

  this.buildForm();
  this.loadDropdowns();
  this.loadLinks();

  this.prefixForm.get('vchrType')?.valueChanges.subscribe(v => {
    console.log('vchrType changed', v);
    this.loadLinks();
  });

  this.prefixForm.get('prefixType')?.valueChanges.subscribe(v => {
    console.log('prefixType changed', v);
    this.loadLinks();
  });
}

  buildForm(): void {
    this.prefixForm = this.fb.group({
      vchrType: ['I', Validators.required],   // Purchase=I, Sales=P
      prefixType: ['D', Validators.required],   // Domestic=D, Import/Export=I
      rows: this.fb.array([])
    });
  }

  get rows(): FormArray {
    return this.prefixForm.get('rows') as FormArray;
  }

  get searchText(): string {
    return this._searchText;
  }

  set searchText(value: string) {
    this._searchText = value ?? '';
    this.updateFilteredIndexes();
  }

  private updateFilteredIndexes(): void {
    const q = this.searchText.trim().toLowerCase();
    this.filteredRowIndexes = [];
    this.rows.controls.forEach((row, i) => {
      if (!q) { this.filteredRowIndexes.push(i); return; }
      const v = row.value;
      if (
        (v.prodPrefix ?? '').toLowerCase().includes(q) ||
        (v.accountCode ?? '').toLowerCase().includes(q) ||
        (v.description ?? '').toLowerCase().includes(q) ||
        (v.customerName ?? '').toLowerCase().includes(q)
      ) {
        this.filteredRowIndexes.push(i);
      }
    });
  }

  get currentModeLabel(): string {
    const v = this.vchrTypeOptions.find(x => x.value === this.prefixForm.get('vchrType')?.value)?.label ?? '';
    const p = this.prefixTypeOptions.find(x => x.value === this.prefixForm.get('prefixType')?.value)?.label ?? '';
    return `${v} — ${p}`;
  }

  accountDescription(code: string): string {
    return this.accountMap.get(code) ?? '';
  }

  customerName(code: string): string {
    return this.customerMap.get(code) ?? '';
  }

  levyLabel(v: string): string { return this.levyTypeOptions.find(x => x.value === v)?.label ?? v; }
  dbcrLabel(v: string): string { return this.dbcrOptions.find(x => x.value === v)?.label ?? v; }

  isProductRow(row: AbstractControl): boolean {
    return row.get('prodLevyType')?.value === 'P';
  }

  isLevyRow(row: AbstractControl): boolean {
    return row.get('prodLevyType')?.value === 'L';
  }

  private createRow(d: Partial<PrefixLinkDto> = {}): FormGroup {
    const levy = d.prodLevyType ?? 'P';
    return this.fb.group({
      prodLevyType: [levy, Validators.required],
      prodPrefix: [d.prodPrefix ?? '', [Validators.required, Validators.maxLength(20)]],
      customerName: [{ value: d.customerName, disabled: true }],
      accountCode: [d.accountCode ?? '', Validators.required],
      description: [{ value: d.description, disabled: true }],
      dbcrFlag: [d.dbcrFlag ?? 'D', Validators.required],
      isNew: [!d.prodPrefix]
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
    this.updateFilteredIndexes();
  }

  removeRow(i: number): void {
    const row = this.rows.at(i);
    if (!row) return;

    if (row.get('isNew')?.value === true) {
      this.rows.removeAt(i);
      this.updateFilteredIndexes();
      return;
    }

    const prodPrefix = row.get('prodPrefix')?.value;
    const accountCode = row.get('accountCode')?.value;
    if (!prodPrefix || !accountCode) { this.rows.removeAt(i); this.updateFilteredIndexes(); return; }

    if (!confirm(`Delete row '${prodPrefix}' → '${accountCode}'?`)) return;

    this.isSaving = true;
    this.svc.deleteLink({
      prodPrefix,
      accountCode,
      vchrType: this.prefixForm.get('vchrType')?.value,
      prefixType: this.prefixForm.get('prefixType')?.value
    })
      .pipe(finalize(() => (this.isSaving = false)))
      .subscribe({
        next: (res: any) => {
          if (res?.success === false) { this.alertService.warning(res?.message || 'Delete failed.'); return; }
          this.alertService.success(res?.message || 'Deleted.');
          this.rows.removeAt(i);
          this.updateFilteredIndexes();
        },
        error: () => this.alertService.error('Delete failed.')
      });
  }

  onLevyTypeChange(i: number): void {
    const row = this.rows.at(i);
    if (!row) return;
    row.get('prodPrefix')?.setValue('');
    row.get('customerName')?.setValue('');
  }

  onPrefixChange(i: number): void {
    const row = this.rows.at(i);
    if (!row) return;
    if (this.isProductRow(row)) {
      const code = row.get('prodPrefix')?.value;
      row.get('customerName')?.setValue(this.customerName(code));
    }
  }

  onAccountChange(i: number): void {
    const row = this.rows.at(i);
    if (!row) return;
    const code = row.get('accountCode')?.value;
    row.get('description')?.setValue(this.accountDescription(code));
  }

  trackByRowIndex(_index: number, rowIndex: number): number {
    return rowIndex;
  }

  isRowInvalid(row: AbstractControl, ctrl: string): boolean {
    const c = row.get(ctrl);
    return !!(c && c.invalid && (c.touched || c.dirty));
  }

  /* ================= DATA ================= */

  // loadDropdowns(): void {
  //   this.svc.getAccounts().subscribe({
  //     next: (res: any) => { this.accountList = Array.isArray(res?.data) ? res.data : [];},
  //     error: () => this.alertService.error('Failed to load accounts.')
  //   });
  //   this.svc.getCustomers().subscribe({
  //     next: (res: any) => { this.customerList = Array.isArray(res?.data) ? res.data : [];},
  //     error: () => this.alertService.error('Failed to load customers.')
  //   });
  // }

  // loadLinks(): void {
  //   const vchr = this.prefixForm.get('vchrType')?.value;
  //   const ptype = this.prefixForm.get('prefixType')?.value;
  //   if (!vchr || !ptype) return;

  //   this.isLoading = true;
  //   this.rows.clear();
  //   this.svc.getLinks(vchr, ptype)
  //     .pipe(finalize(() => (this.isLoading = false)))
  //     .subscribe({
  //       next: (res: any) => {
  //         const list: PrefixLinkDto[] = Array.isArray(res?.data) ? res.data : [];
  //         list.forEach(item => this.rows.push(this.createRow(item)));
  //       },
  //       error: () => this.alertService.error('Failed to load prefix links.')
  //     });
  // }

  private unwrapArray<T>(res: any): T[] {
    if (Array.isArray(res)) {
      return res;
    }
    if (Array.isArray(res?.data)) {
      return res.data;
    }
    return [];
  }

  loadDropdowns(): void {
    this.svc.getAccounts().subscribe({
      next: (res: any) => {
        this.accountList = this.unwrapArray<AccountLookupDto>(res);
        this.updateLookupMaps();
      },
      error: (err) => {
        console.error('GetAccounts Error:', err);
        this.alertService.error('Failed to load accounts.');
      }
    });

    this.svc.getCustomers().subscribe({
      next: (res: any) => {
        this.customerList = this.unwrapArray<CustomerLookupDto>(res);
        this.updateLookupMaps();
      },
      error: (err) => {
        console.error('GetCustomers Error:', err);
        this.alertService.error('Failed to load customers.');
      }
    });
  }

  private updateLookupMaps(): void {
    this.accountMap = new Map(this.accountList.map(a => [a.accountCode, a.description]));
    this.customerMap = new Map(this.customerList.map(c => [c.customerCode, c.customerName]));
  }

  loadLinks(): void {
    const vchr = this.prefixForm.get('vchrType')?.value;
    const ptype = this.prefixForm.get('prefixType')?.value;

    if (!vchr || !ptype) {
      return;
    }

    this.isLoading = true;
    console.time('LoadLinks API');
    this.rows.clear();

    this.svc.getLinks(vchr, ptype)
      .pipe(
        finalize(() => {
          this.isLoading = false;
          console.timeEnd('LoadLinks API');
        })
      )
      .subscribe({
        next: (res: any) => {
          const list: PrefixLinkDto[] = this.unwrapArray<PrefixLinkDto>(res);
          list.forEach((item) => this.rows.push(this.createRow(item)));
          this.updateFilteredIndexes();
        },
        error: (err) => {
          console.error('GetLinks Error:', err);
          this.alertService.error('Failed to load prefix links.');
        }
      });
  }

  onSave(): void {
    this.prefixForm.markAllAsTouched();
    if (this.prefixForm.invalid) {
      this.alertService.warning('Please fix the highlighted rows.');
      return;
    }
    if (this.rows.length === 0) { this.alertService.warning('Add at least one row.'); return; }

    const seen = new Set<string>();
    for (const r of this.rows.controls) {
      const key = `${r.get('prodPrefix')?.value}||${r.get('accountCode')?.value}`;
      if (seen.has(key)) {
        this.alertService.warning(`Duplicate row: ${r.get('prodPrefix')?.value} / ${r.get('accountCode')?.value}`);
        return;
      }
      seen.add(key);
    }

    const payload = {
      vchrType: this.prefixForm.get('vchrType')?.value,
      prefixType: this.prefixForm.get('prefixType')?.value,
      username: this.userName,
      location: 'BILZ',
      rows: this.rows.getRawValue().map((r: any) => ({
        prodPrefix: r.prodPrefix,
        accountCode: r.accountCode,
        prodLevyType: r.prodLevyType,
        dbcrFlag: r.dbcrFlag
      }))
    };

    this.isSaving = true;
    this.svc.saveLinks(payload)
      .pipe(finalize(() => (this.isSaving = false)))
      .subscribe({
        next: (res: any) => {
          if (res?.success === false) { this.alertService.warning(res?.message || 'Failed to save.'); return; }
          this.alertService.success(res?.message || 'Saved successfully.');
          this.loadLinks();
        },
        error: () => this.alertService.error('Save failed.')
      });
  }

  onRefresh(): void {
    this.searchText = '';
    this.loadLinks();
  }
}
