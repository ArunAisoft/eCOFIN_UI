import { Component, OnInit } from '@angular/core';
import { DefinePrefixService } from '../../services/define-prefix.service';
import {
  ApiResponse,
  CustomerLookupDto,
  AccountLookupDto,
  PrefixLinkDto,
  PrefixLinkWithHistoryDto,
  MonthlyPrefixSummaryDto,
  PrefixTransactionHistoryDto,
  SavePrefixLinksRequest
} from '../../models/define-prefix.models';

@Component({
  selector: 'app-define-prefix',
  templateUrl: './define-prefix.component.html',
  styleUrls: ['./define-prefix.component.css']
})
export class DefinePrefixComponent implements OnInit {
  customers: CustomerLookupDto[] = [];
  accounts: AccountLookupDto[] = [];
  prefixLinks: PrefixLinkDto[] = [];
  prefixLinksWithHistory: PrefixLinkWithHistoryDto[] = [];
  transactionHistory: PrefixTransactionHistoryDto[] = [];

  selectedVchrType: string = '';
  selectedPrefixType: string = '';
  selectedAccountCode: string = '';

  loadingCustomers = false;
  loadingAccounts = false;
  loadingLinks = false;
  loadingHistory = false;

  errorMessage: string = '';

  constructor(private prefixService: DefinePrefixService) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  loadInitialData(): void {
    this.loadCustomers();
    this.loadAccounts();
  }

  loadCustomers(): void {
    this.loadingCustomers = true;
    this.prefixService.getCustomers().subscribe({
      next: (response: ApiResponse<CustomerLookupDto[]>) => {
        if (response.success && response.data) {
          this.customers = response.data;
        } else {
          this.showError(response.message || 'Failed to load customers');
        }
      },
      error: (error: any) => {
        this.showError(`Error loading customers: ${error?.message || error}`);
      },
      complete: () => {
        this.loadingCustomers = false;
      }
    });
  }

  loadAccounts(): void {
    this.loadingAccounts = true;
    this.prefixService.getAccounts().subscribe({
      next: (response: ApiResponse<AccountLookupDto[]>) => {
        if (response.success && response.data) {
          this.accounts = response.data;
        } else {
          this.showError(response.message || 'Failed to load accounts');
        }
      },
      error: (error: any) => {
        this.showError(`Error loading accounts: ${error?.message || error}`);
      },
      complete: () => {
        this.loadingAccounts = false;
      }
    });
  }

  loadPrefixLinks(): void {
    if (!this.selectedVchrType || !this.selectedPrefixType) {
      this.showError('Please select both Voucher Type and Prefix Type');
      return;
    }

    this.loadingLinks = true;
    this.prefixService.getLinks(this.selectedVchrType, this.selectedPrefixType).subscribe({
      next: (response: ApiResponse<PrefixLinkDto[]>) => {
        if (response.success && response.data) {
          this.prefixLinks = response.data;
          this.clearError();
        } else {
          this.showError(response.message || 'Failed to load prefix links');
        }
      },
      error: (error: any) => {
        this.showError(`Error loading prefix links: ${error?.message || error}`);
      },
      complete: () => {
        this.loadingLinks = false;
      }
    });
  }

  loadPrefixLinksWithHistory(): void {
    if (!this.selectedVchrType || !this.selectedPrefixType) {
      this.showError('Please select both Voucher Type and Prefix Type');
      return;
    }

    this.loadingLinks = true;
    this.prefixService.getLinksWithLast3Months(this.selectedVchrType, this.selectedPrefixType).subscribe({
      next: (response: ApiResponse<PrefixLinkWithHistoryDto[]>) => {
        if (response.success && response.data) {
          this.prefixLinksWithHistory = response.data;
          this.clearError();
        } else {
          this.showError(response.message || 'Failed to load prefix links with history');
        }
      },
      error: (error: any) => {
        this.showError(`Error loading prefix links with history: ${error?.message || error}`);
      },
      complete: () => {
        this.loadingLinks = false;
      }
    });
  }

  loadTransactionHistory(accountCode: string, vchrType: string, months: number = 3): void {
    this.loadingHistory = true;
    this.prefixService.getTransactionHistory(accountCode, vchrType, months).subscribe({
      next: (response: ApiResponse<PrefixTransactionHistoryDto[]>) => {
        if (response.success && response.data) {
          this.transactionHistory = response.data;
          this.clearError();
        } else {
          this.showError(response.message || 'Failed to load transaction history');
        }
      },
      error: (error: any) => {
        this.showError(`Error loading transaction history: ${error?.message || error}`);
      },
      complete: () => {
        this.loadingHistory = false;
      }
    });
  }

  showError(message: string): void {
    this.errorMessage = message;
    console.error(message);
  }

  clearError(): void {
    this.errorMessage = '';
  }

  getTotalAmount(months: MonthlyPrefixSummaryDto[]): number {
    return months?.reduce((sum, m) => sum + (m.totalAmount ?? 0), 0) ?? 0;
  }

  getTotalPostedCount(months: MonthlyPrefixSummaryDto[]): number {
    return months?.reduce((sum, m) => sum + (m.postedCount ?? 0), 0) ?? 0;
  }

  getTotalOnHoldCount(months: MonthlyPrefixSummaryDto[]): number {
    return months?.reduce((sum, m) => sum + (m.onHoldCount ?? 0), 0) ?? 0;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  formatDate(date: Date | string): string {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-IN');
  }
}
