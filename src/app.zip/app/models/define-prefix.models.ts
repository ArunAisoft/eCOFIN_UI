// ========== API Response Wrapper ==========
export interface ApiResponse<T = any> {
  success: boolean;
  status: number;
  message: string;
  data?: T;
  error?: string;
}

// ========== Data Models ==========

export interface CustomerLookupDto {
  customerCode: string;
  customerName: string;
}

export interface AccountLookupDto {
  accountCode: string;
  description: string;
}

export interface PrefixLinkDto {
  prodPrefix: string;
  accountCode: string;
  description: string;
  vchrType: string;
  prodPrefixType: string;
  prodLevyType: string;  // 'L' or 'P'
  dbcrFlag: string;      // 'D' or 'C'
  customerName: string;
  objectStatus?: string;
}

export interface MonthlyPrefixSummaryDto {
  accPeriod: string;
  transactionCount: number;
  totalAmount: number;
  postedCount: number;
  onHoldCount: number;
}

export interface PrefixLinkWithHistoryDto extends PrefixLinkDto {
  last3MonthsData: MonthlyPrefixSummaryDto[];
}

export interface PrefixTransactionHistoryDto {
  voucherNumber: string;
  voucherDate: Date;
  accPeriod: string;
  voucherGroup: string;
  amount: number;
  dbCrFlag: string;
  status: string;
  description: string;
}

// ========== Request Models ==========

export interface PrefixRowPayload {
  prodPrefix: string;
  accountCode: string;
  prodLevyType: string;  // 'L' or 'P'
  dbcrFlag: string;      // 'D' or 'C'
}

export interface SavePrefixLinksRequest {
  vchrType: string;
  prefixType: string;
  rows: PrefixRowPayload[];
  username?: string;
  location?: string;
}

export interface DeletePrefixLinkRequest {
  prodPrefix: string;
  accountCode: string;
  vchrType: string;
  prefixType: string;
}
