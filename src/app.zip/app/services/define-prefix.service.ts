import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  ApiResponse,
  CustomerLookupDto,
  AccountLookupDto,
  PrefixLinkDto,
  PrefixLinkWithHistoryDto,
  PrefixTransactionHistoryDto,
  SavePrefixLinksRequest,
  DeletePrefixLinkRequest
} from '../models/define-prefix.models';

@Injectable({
  providedIn: 'root'
})
export class DefinePrefixService {
  private apiUrl = 'http://localhost:5000/eCOFIN_API/api/DefinePrefix';

  constructor(private http: HttpClient) { }

  // ========== GET ENDPOINTS - Data Loading ==========

  getCustomers(): Observable<ApiResponse<CustomerLookupDto[]>> {
    return this.http.get<ApiResponse<CustomerLookupDto[]>>(
      `${this.apiUrl}/GetCustomers`
    );
  }

  getAccounts(): Observable<ApiResponse<AccountLookupDto[]>> {
    return this.http.get<ApiResponse<AccountLookupDto[]>>(
      `${this.apiUrl}/GetAccounts`
    );
  }

  getLinks(vchrType: string, prefixType: string): Observable<ApiResponse<PrefixLinkDto[]>> {
    return this.http.get<ApiResponse<PrefixLinkDto[]>>(
      `${this.apiUrl}/GetLinks/${vchrType}/${prefixType}`
    );
  }

  getLinksWithLast3Months(vchrType: string, prefixType: string): Observable<ApiResponse<PrefixLinkWithHistoryDto[]>> {
    return this.http.get<ApiResponse<PrefixLinkWithHistoryDto[]>>(
      `${this.apiUrl}/GetLinksWithLast3Months/${vchrType}/${prefixType}`
    );
  }

  getTransactionHistory(
    accountCode: string,
    vchrType: string,
    monthsBack: number = 3
  ): Observable<ApiResponse<PrefixTransactionHistoryDto[]>> {
    const params = new HttpParams().set('monthsBack', monthsBack.toString());
    return this.http.get<ApiResponse<PrefixTransactionHistoryDto[]>>(
      `${this.apiUrl}/GetPrefixTransactionHistory/${accountCode}/${vchrType}`,
      { params }
    );
  }

  // ========== POST ENDPOINTS - Save/Delete ==========

  saveLinks(request: SavePrefixLinksRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(
      `${this.apiUrl}/SaveLinks`,
      request
    );
  }

  deleteLink(request: DeletePrefixLinkRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(
      `${this.apiUrl}/DeleteLink`,
      request
    );
  }
}
